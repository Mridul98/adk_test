## installation
1. run `pip install -r requirements.txt`

## indexing
1. run `graphrag index --root './generated_text_docs'`

## Note: No need to run indexing if you have already initialized the project. Use drift_search_v2.ipynb for drift search